package com.example.meteoconnectsa.model

data class WeatherResponse(
    val name: String,
    val main: Main,
    val wind: Wind,
    val sys: Sys
)

data class Main(val temp: Double, val humidity: Int)
data class Wind(val speed: Double)
data class Sys(val sunrise: Long)
