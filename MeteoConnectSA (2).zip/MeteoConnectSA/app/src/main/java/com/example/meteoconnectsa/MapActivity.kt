package com.example.meteoconnectsa

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var navHome: TextView
    private lateinit var navForecast: TextView
    private lateinit var navMap: TextView
    private lateinit var navSettings: TextView
    private lateinit var mapView: MapView
    private lateinit var mapLoadingOverlay: View

    private lateinit var googleMap: GoogleMap

    // Durban coordinates
    private val durbanLocation = LatLng(-29.8587, 31.0218)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)

        initializeViews()
        setupNavigation()
        initializeMapView(savedInstanceState)
    }

    private fun initializeViews() {
        navHome = findViewById(R.id.nav_home)
        navForecast = findViewById(R.id.nav_forecast)
        navMap = findViewById(R.id.nav_map)
        navSettings = findViewById(R.id.nav_settings)
        mapView = findViewById(R.id.mapView)
        mapLoadingOverlay = findViewById(R.id.mapLoadingOverlay)
    }

    private fun initializeMapView(savedInstanceState: Bundle?) {
        // Initialize the map view
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        this.googleMap = googleMap

        // Configure the map
        googleMap.uiSettings.isZoomControlsEnabled = true
        googleMap.uiSettings.isCompassEnabled = true
        googleMap.uiSettings.isMapToolbarEnabled = true

        // Add marker for Durban
        googleMap.addMarker(
            MarkerOptions()
                .position(durbanLocation)
                .title("Durban")
                .snippet("Weather location")
        )

        // Move camera to Durban
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(durbanLocation, 12f))

        // Hide loading overlay
        mapLoadingOverlay.visibility = View.GONE
    }

    private fun setupNavigation() {
        navHome.setOnClickListener {
            val intent = Intent(this@MapActivity, HomeActivity::class.java)
            startActivity(intent)
            finish()
        }

        navForecast.setOnClickListener {
            val intent = Intent(this@MapActivity, ForecastActivity::class.java)
            startActivity(intent)
            finish()
        }

        navMap.setOnClickListener {
            // Already on map screen
        }

        navSettings.setOnClickListener {
            val intent = Intent(this@MapActivity, SettingsActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    // MapView lifecycle methods
    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView.onSaveInstanceState(outState)
    }
}