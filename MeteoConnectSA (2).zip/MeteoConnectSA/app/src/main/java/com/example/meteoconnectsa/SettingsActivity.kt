package com.example.meteoconnectsa

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        setupNavigation()
        setupSettingsButtons()
    }

    private fun setupNavigation() {
        findViewById<TextView>(R.id.nav_home).setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        findViewById<TextView>(R.id.nav_forecast).setOnClickListener {
            startActivity(Intent(this, ForecastActivity::class.java))
            finish()
        }

        findViewById<TextView>(R.id.nav_map).setOnClickListener {
            startActivity(Intent(this, MapActivity::class.java))
            finish()
        }

        findViewById<TextView>(R.id.nav_settings).setOnClickListener {
            // Already on settings screen
        }
    }

    private fun setupSettingsButtons() {
        // Notifications button
        findViewById<android.view.View>(R.id.notifications_option).setOnClickListener {
            val intent = Intent(this, NotificationsActivity::class.java)
            startActivity(intent)
        }

        // Units button
        findViewById<android.view.View>(R.id.units_option).setOnClickListener {
            val intent = Intent(this, UnitsActivity::class.java)
            startActivity(intent)
        }

        // Language button
        findViewById<android.view.View>(R.id.language_option).setOnClickListener {
            val intent = Intent(this, LanguageActivity::class.java)
            startActivity(intent)
        }

        // About button
        findViewById<android.view.View>(R.id.about_option).setOnClickListener {
            val intent = Intent(this, AboutActivity::class.java)
            startActivity(intent)
        }

        // Privacy button
        findViewById<android.view.View>(R.id.privacy_option).setOnClickListener {
            val intent = Intent(this, PrivacyActivity::class.java)
            startActivity(intent)
        }
    }
}