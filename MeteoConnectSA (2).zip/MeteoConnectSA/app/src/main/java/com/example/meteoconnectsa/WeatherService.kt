package com.example.meteoconnectsa.api

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query
import com.example.meteoconnectsa.model.WeatherResponse

interface WeatherService {
    @GET("data/2.5/weather")
    fun getCurrentWeather(
        @Query("q") city: String,
        @Query("appid") apiKey: String,
        @Query("exclude") exclude: String = "minutely,hourly,alerts",
        @Query("units") units: String
    ): Call<WeatherResponse>
}
