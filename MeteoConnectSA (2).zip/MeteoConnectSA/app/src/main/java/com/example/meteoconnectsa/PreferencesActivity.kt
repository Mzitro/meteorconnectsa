package com.example.meteoconnectsa

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.switchmaterial.SwitchMaterial

class PreferencesActivity : AppCompatActivity() {

    private lateinit var btnSavePrefs: Button
    private lateinit var switchAutoDetect: SwitchMaterial
    private lateinit var switchDailyTips: SwitchMaterial
    private lateinit var switchSevereAlerts: SwitchMaterial
    private lateinit var cbCasualWear: MaterialCheckBox
    private lateinit var cbFormalWear: MaterialCheckBox
    private lateinit var cbSportyWear: MaterialCheckBox

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preferences)

        // Initialize views
        btnSavePrefs = findViewById(R.id.btnSavePrefs)
        switchAutoDetect = findViewById(R.id.switchAutoDetect)
        switchDailyTips = findViewById(R.id.switchDailyTips)
        switchSevereAlerts = findViewById(R.id.switchSevereAlerts)
        cbCasualWear = findViewById(R.id.cbCasualWear)
        cbFormalWear = findViewById(R.id.cbFormalWear)
        cbSportyWear = findViewById(R.id.cbSportyWear)

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        // Load saved preferences
        loadPreferences()

        btnSavePrefs.setOnClickListener {
            savePreferences()
            Toast.makeText(this@PreferencesActivity, "Preferences saved", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadPreferences() {
        switchAutoDetect.isChecked = prefs.getBoolean(KEY_AUTO_DETECT, true)
        switchDailyTips.isChecked = prefs.getBoolean(KEY_DAILY_TIPS, true)
        switchSevereAlerts.isChecked = prefs.getBoolean(KEY_SEVERE_ALERTS, true)
        cbCasualWear.isChecked = prefs.getBoolean(KEY_CASUAL_WEAR, false)
        cbFormalWear.isChecked = prefs.getBoolean(KEY_FORMAL_WEAR, true)
        cbSportyWear.isChecked = prefs.getBoolean(KEY_SPORTY_WEAR, true)
    }

    private fun savePreferences() {
        val editor = prefs.edit()
        editor.putBoolean(KEY_AUTO_DETECT, switchAutoDetect.isChecked)
        editor.putBoolean(KEY_DAILY_TIPS, switchDailyTips.isChecked)
        editor.putBoolean(KEY_SEVERE_ALERTS, switchSevereAlerts.isChecked)
        editor.putBoolean(KEY_CASUAL_WEAR, cbCasualWear.isChecked)
        editor.putBoolean(KEY_FORMAL_WEAR, cbFormalWear.isChecked)
        editor.putBoolean(KEY_SPORTY_WEAR, cbSportyWear.isChecked)
        editor.apply()
    }

    companion object {
        private const val PREFS_NAME = "AppSettings"
        private const val KEY_AUTO_DETECT = "auto_detect"
        private const val KEY_DAILY_TIPS = "daily_tips"
        private const val KEY_SEVERE_ALERTS = "severe_alerts"
        private const val KEY_CASUAL_WEAR = "casual_wear"
        private const val KEY_FORMAL_WEAR = "formal_wear"
        private const val KEY_SPORTY_WEAR = "sporty_wear"
    }
}