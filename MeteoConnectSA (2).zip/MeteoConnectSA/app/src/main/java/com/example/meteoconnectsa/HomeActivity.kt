package com.example.meteoconnectsa

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

class HomeActivity : AppCompatActivity() {

    private var tvWelcome: TextView? = null
    private var tvCity: TextView? = null
    private var tvTemperature: TextView? = null
    private var tvHumidity: TextView? = null
    private var tvWind: TextView? = null
    private var tvSunrise: TextView? = null
    private var btnForecast: Button? = null
    private var btnMap: Button? = null
    private var btnPreferences: Button? = null
    private var btnSettings: Button? = null

    private var auth: FirebaseAuth? = null
    private val city = "Durban"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        auth = FirebaseAuth.getInstance()

        initializeViews()
        setWelcomeMessage()
        setWeatherData()
        setClickListeners()
    }

    private fun initializeViews() {
        tvWelcome = findViewById(R.id.tvWelcome)
        tvCity = findViewById(R.id.tvCity)
        tvTemperature = findViewById(R.id.tvTemperature)
        tvHumidity = findViewById(R.id.tvHumidity)
        tvWind = findViewById(R.id.tvWind)
        tvSunrise = findViewById(R.id.tvSunrise)

        btnForecast = findViewById(R.id.btnForecast)
        btnMap = findViewById(R.id.btnMap)
        btnPreferences = findViewById(R.id.btnPreferences)
        btnSettings = findViewById(R.id.btnSettings)
    }

    private fun setWelcomeMessage() {
        val user: FirebaseUser? = auth?.currentUser
        val welcomeMessage = when {
            user != null && !user.displayName.isNullOrEmpty() -> "Hello, ${user.displayName}"
            user != null -> "Hello, ${user.email?.substringBefore('@') ?: "User"}"
            else -> "Hello, Anenhle"
        }
        tvWelcome?.text = welcomeMessage
    }

    private fun setWeatherData() {
        tvCity?.text = city
        tvTemperature?.text = "26°C"
        tvHumidity?.text = "Humidity: 40%"
        tvWind?.text = "Wind: 15 km/h"
        tvSunrise?.text = "Sunrise: 6:20"
    }

    private fun setClickListeners() {
        btnForecast?.setOnClickListener {
            val intent = Intent(this@HomeActivity, ForecastActivity::class.java)
            startActivity(intent)
        }

        btnMap?.setOnClickListener {
            val intent = Intent(this@HomeActivity, MapActivity::class.java)
            startActivity(intent)
        }

        btnPreferences?.setOnClickListener {
            val intent = Intent(this@HomeActivity, PreferencesActivity::class.java)
            startActivity(intent)
        }

        btnSettings?.setOnClickListener {
            val intent = Intent(this@HomeActivity, SettingsActivity::class.java)
            startActivity(intent)
        }
    }
}
