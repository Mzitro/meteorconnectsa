package com.example.meteoconnectsa

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class WelcomeActivity : AppCompatActivity() {
    private var btnGetStarted: Button? = null
    private var btnLogin: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)

        btnGetStarted = findViewById<Button?>(R.id.btnGetStarted)
        btnLogin = findViewById<Button?>(R.id.btnLogin)

        btnGetStarted!!.setOnClickListener(View.OnClickListener { v: View? ->
            val intent: Intent = Intent(this@WelcomeActivity, SignUpActivity::class.java)
            startActivity(intent)
        })

        btnLogin!!.setOnClickListener(View.OnClickListener { v: View? ->
            val intent: Intent = Intent(this@WelcomeActivity, LoginActivity::class.java)
            startActivity(intent)
        })
    }
}